export class Dischargedpatientlist {
    d_name!: string;
    p_name!: string;
    d_id!: number;
    confirm!: string;
    d_date!: string; 
    d_time!: string;
    disease!: string;
}
