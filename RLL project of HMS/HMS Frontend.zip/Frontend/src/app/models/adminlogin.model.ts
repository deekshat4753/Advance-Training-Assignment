export class Admin {
    id : number | undefined;
    emailId:String | undefined;
    userName:String | undefined;
    password:String | undefined;

    constructor(){}
}