import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletea',
  templateUrl: './deletea.component.html',
  styleUrls: ['./deletea.component.css']
})
export class DeleteaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
